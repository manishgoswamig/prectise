<?php
namespace Ktpl\Catalog\Plugin;

class PluginB
{
    public function beforeExecute()
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/logfile.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('----------------------------------------');
        $logger->info(get_class().' :: '.__FUNCTION__);
    }

    public function aroundExecute(\Ktpl\Catalog\Controller\Normal\Test\Method\Index $subject, callable $proceed)
    {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/logfile.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('----------------------------------------');
        $logger->info(get_class().' :: '.__FUNCTION__);

        $result = $proceed();
        return $result;
    }

    public function afterExecute(\Ktpl\Catalog\Controller\Normal\Test\Method\Index $subject,$result)
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/logfile.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('----------------------------------------');
        $logger->info(get_class().' :: '.__FUNCTION__);
        return $result;
    }

}
