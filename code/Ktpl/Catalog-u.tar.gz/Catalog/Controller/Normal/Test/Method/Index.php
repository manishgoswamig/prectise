<?php
namespace Ktpl\Catalog\Controller\Normal\Test\Method;

use \Magento\Framework\App\Action\Action;

class Index extends Action
{
    /** @var  \Magento\Framework\View\Result\Page */
    protected $resultPageFactory;

    protected $fruits;

    /**
     *
     * Dependency Injection.
     * This will be explained in the next part of the blog series/next tag.
     *
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        array $fruits = []
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->fruits = $fruits;
        /*$this->helper = $ktplHelper;*/
        parent::__construct($context);
    }

    /**
     * Index, shows the content defined in view/frontend/layout/helloworld.xml
     *
     * @return \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
        return $this->resultPageFactory->create();
    }
}
